﻿using DataEngine.TransactionService.Domain;
using DataEngine.TransactionService.Enums;
using DataEngine.TransactionService.Interfaces;
using System.Data;

namespace DataEngine.TransactionService.Services;

public sealed class TransactionService : ITransactionService
{
    private readonly IDataProvider _dataProvider;
    private readonly ISqlGuardian _sqlGuardian;
    private readonly IFieldMapperRepository _fieldMapperRepository;
    private readonly IDataTypeConverter _dataTypeConverter;
    private readonly IModelBinder _modelBinder;
    private readonly IAuditService? _auditService;
    private readonly ILogger<TransactionService> _logger;

    public TransactionService(
        IDataProvider dataProvider, ISqlGuardian sqlGuardian, IFieldMapperRepository fieldMapperRepository,
        IDataTypeConverter dataTypeConverter, IModelBinder modelBinder,
        ILogger<TransactionService> logger, IAuditService? auditService = null)
    {
        _dataProvider = dataProvider; _sqlGuardian = sqlGuardian; _fieldMapperRepository = fieldMapperRepository;
        _dataTypeConverter = dataTypeConverter; _modelBinder = modelBinder; _logger = logger; _auditService = auditService;
    }

    public async Task<TransactionResult> ExecuteAsync(TransactionCommand command, CancellationToken ct = default)
    {
        var transactionId = string.IsNullOrWhiteSpace(command.TransactionId) ? Guid.NewGuid().ToString("N") : command.TransactionId;
        ValidateCommand(command);

        return await _dataProvider.ExecuteInTransactionAsync(async (connection, transaction) =>
        {
            return command.Mode switch
            {
                BindingMode.FieldMapper => await ExecuteFieldMapperPathAsync(command, transaction, transactionId, ct),
                BindingMode.Model => await ExecuteModelPathAsync(command, transaction, transactionId, ct),
                _ => throw new NotSupportedException($"Binding mode '{command.Mode}' is not supported.")
            };
        }, ct).ConfigureAwait(false);
    }

    // ── Path 1: field mapper (dynamic, schema-driven) ─────────────────────────
    // This is the existing TransactionEngine logic (InsertMainRecordAsync / UpdateMainRecordAsync /
    // ProcessChildRecordsAsync / ProcessDeletionsAsync), moved here unchanged — it already handles
    // Insert vs Update detection, child records (RenProps), deletions (DelProps), and audit logging.
    private async Task<TransactionResult> ExecuteFieldMapperPathAsync(
        TransactionCommand command, IDbTransaction transaction, string transactionId, CancellationToken ct)
    {
        var request = command.FieldMapperPayload
            ?? throw new TransactionProcessingException(command.EntityName, transactionId, "Validate",
                "FieldMapperPayload is required when Mode is BindingMode.FieldMapper.");

        var mappers = await _fieldMapperRepository.GetFieldMappersAsync(request.TransactionEntityName, transaction, ct);
        if (mappers.Count == 0)
            throw new TransactionProcessingException(request.TransactionEntityName, transactionId, "ResolveMappers",
                $"No field mappers found for entity '{request.TransactionEntityName}'.");

        var (recordId, opType) = command.Operation switch
        {
            TransactionOperationType.Delete => (await DeleteViaFieldMapperAsync(request, transaction, ct), "Delete"),
            TransactionOperationType.Update => ((await UpdateMainRecordAsync(request, mappers, transaction, transactionId, ct)).RecordId, "Update"),
            _ => (await InsertMainRecordAsync(request, mappers, transaction, transactionId, ct), "Insert")
        };

        if (request.RenProps.Count > 0) await ProcessChildRecordsAsync(request, recordId, transaction, transactionId, ct);
        if (request.DelProps.Count > 0) await ProcessDeletionsAsync(request, transaction, transactionId, ct);

        return new TransactionResult
        {
            Success = true,
            TransactionId = transactionId,
            Message = $"Transaction completed. Operation: {opType}.",
            Data = new Dictionary<string, object> { ["RecordId"] = recordId }
        };
        // InsertMainRecordAsync / UpdateMainRecordAsync / ProcessChildRecordsAsync / ProcessDeletionsAsync /
        // DeleteViaFieldMapperAsync are the private helpers already implemented in the current
        // DataEngine.Core/Services/TransactionEngine.cs — copy them into this class as-is.
    }

    // ── Path 2: strongly-typed model binding (new) ────────────────────────────
    private async Task<TransactionResult> ExecuteModelPathAsync(
        TransactionCommand command, IDbTransaction transaction, string transactionId, CancellationToken ct)
    {
        var model = command.Model
            ?? throw new TransactionProcessingException(command.EntityName, transactionId, "Validate",
                "Model is required when Mode is BindingMode.Model.");

        var metadata = _modelBinder.GetMetadata(model.GetType());
        var tableName = _sqlGuardian.ValidateIdentifier(metadata.TableName, "table name");

        var sql = command.Operation switch
        {
            TransactionOperationType.Insert => BuildInsertSql(tableName, metadata, model, out var insertParams),
            TransactionOperationType.Update => BuildUpdateSql(tableName, metadata, model, out var updateParams),
            TransactionOperationType.Delete => BuildDeleteSql(tableName, metadata, model, out var deleteParams),
            _ => throw new NotSupportedException($"Operation '{command.Operation}' is not supported.")
        };

        // (sql, parameters) — see helper signatures below; each returns the built statement
        // and outputs a Dictionary<string, object> of bound parameter values.
        var (statement, parameters, recordId) = BuildModelStatement(tableName, metadata, model, command.Operation);

        var rowsAffected = await _dataProvider.ExecuteNonQueryAsync(statement, parameters, transaction, ct);
        if (rowsAffected == 0 && command.Operation != TransactionOperationType.Insert)
            throw new TransactionProcessingException(tableName, transactionId, command.Operation.ToString(),
                $"No record affected for key '{recordId}' in table '{tableName}'.");

        if (_auditService != null)
        {
            var auditOp = command.Operation switch
            {
                TransactionOperationType.Insert => AuditOperation.Create,
                TransactionOperationType.Update => AuditOperation.Update,
                _ => AuditOperation.Delete
            };
            _ = _auditService.AuditAsync(tableName, recordId!, auditOp, command.UserId ?? string.Empty, null, null, ct);
        }

        return new TransactionResult
        {
            Success = true,
            TransactionId = transactionId,
            Message = $"Transaction completed. Operation: {command.Operation}.",
            Data = new Dictionary<string, object> { ["RecordId"] = recordId! }
        };
    }

    // BuildInsertSql / BuildUpdateSql / BuildDeleteSql: walk metadata.Columns, skip AutoGenerated
    // key on insert (or generate it the same way GenerateId(...) does today), use
    // _sqlGuardian.ValidateIdentifier on every column name and _dataProvider.GetParameterPlaceholder
    // for every value placeholder — identical security posture to the field-mapper path, just
    // reading column names from ModelMetadata instead of from FieldMapper rows.

    private void ValidateCommand(TransactionCommand command)
    {
        if (string.IsNullOrWhiteSpace(command.EntityName))
            throw new TransactionProcessingException("(unknown)", command.TransactionId ?? "(null)", "Validate", "EntityName is required.");

        if (command.Mode == BindingMode.FieldMapper && command.FieldMapperPayload == null)
            throw new TransactionProcessingException(command.EntityName, command.TransactionId ?? "(null)", "Validate",
                "FieldMapperPayload is required for BindingMode.FieldMapper.");

        if (command.Mode == BindingMode.Model && command.Model == null)
            throw new TransactionProcessingException(command.EntityName, command.TransactionId ?? "(null)", "Validate",
                "Model is required for BindingMode.Model.");
    }
}