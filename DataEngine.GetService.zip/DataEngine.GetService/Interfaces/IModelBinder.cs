﻿using DataEngine.TransactionService.Domain;

namespace DataEngine.TransactionService.Interfaces;

public interface IModelBinder
{
    ModelMetadata GetMetadata(Type modelType);
}