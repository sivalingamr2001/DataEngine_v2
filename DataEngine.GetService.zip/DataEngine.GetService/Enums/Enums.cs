﻿namespace DataEngine.TransactionService.Enums;

public enum BindingMode { FieldMapper, Model }
public enum TransactionOperationType { Insert, Update, Delete }