﻿using DataEngine.Core.Domain;
using DataEngine.Core.Infrastructure;
using DataEngine.Core.Interfaces;
using DataEngine.Core.Providers;
using Microsoft.Extensions.DependencyInjection;

namespace DataEngine.Core.Services;

public static class ServiceRegistrationExtensions
{
    public static IServiceCollection AddDataEngineCoreServices(this IServiceCollection services, DatabaseConfig databaseConfig)
    {
        services.AddSingleton(databaseConfig);

        // Connection factory
        services.AddSingleton<DatabaseConnectionFactory>();
        services.AddSingleton<IDatabaseConnectionFactory>(sp => sp.GetRequiredService<DatabaseConnectionFactory>());

        // Provider strategies
        services.AddSingleton<IDbProviderStrategy, MySqlProviderStrategy>();
        services.AddSingleton<IDbProviderStrategy, OracleProviderStrategy>();
        services.AddSingleton<IDbProviderStrategy, SqlServerProviderStrategy>();
        services.AddSingleton<IDbProviderStrategyFactory, DbProviderStrategyFactory>();

        return services;
    }
}
