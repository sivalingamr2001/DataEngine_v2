﻿namespace DataEngine.Core.Interfaces;

internal interface IDataEngine
{
}
