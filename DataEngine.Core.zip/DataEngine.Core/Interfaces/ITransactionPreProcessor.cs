﻿using DataEngine.Core.Domain;

namespace DataEngine.Core.Interfaces;

public interface ITransactionPreProcessor
{
    void Prepare(TransactionRequest request);
    void Prepare(FetchConfig query);
}
