namespace DataEngine.Core.Interfaces;

public interface ITableNameValidator
{
    Task EnsureAllowedAsync(string tableName, CancellationToken ct = default);
}
