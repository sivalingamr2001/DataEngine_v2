using System.Data.Common;

namespace DataEngine.Core.Interfaces;

public interface IDatabaseConnectionFactory
{
    Task<DbConnection> CreateMasterConnectionAsync(CancellationToken ct = default);
    Task<DbConnection> CreateReadReplicaConnectionAsync(CancellationToken ct = default);
}
