using DataEngine.Core.Domain;
using DataEngine.Core.Interfaces;

namespace DataEngine.Core.Providers;

public interface IDbProviderStrategyFactory
{
    IDbProviderStrategy Get(DatabaseProvider provider);
}
